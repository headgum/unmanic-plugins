# Changelog

## v0.1.0

- Initial release
- Added support for Slack notifications when files are moved or copied
- Added support for Slack notifications when tasks are completed
- Added configuration options for webhook URL, channel, username, and icon emoji
- Added options to enable/disable different notification types 